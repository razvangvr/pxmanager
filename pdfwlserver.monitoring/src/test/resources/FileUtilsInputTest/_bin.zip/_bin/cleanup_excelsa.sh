#!/bin/sh
# clean up log files of excelsa

. /appl/mars/bin/excelsa_node_conf

if [ `whoami` != "mars" ]; then
    su - mars -c "${BASE_DIR}/bin/cleanup_excelsa.sh"
else

    cd ${EXCELSA_SERVER_LOG_DIR} &&  find . -name '*.log*' -mtime +21 | xargs rm -f

    #cleanup import directories
    #directories for incoming files
    cd ${EXCELSA_IMPORT_DIR}/coremedia &&  find . -name '*' -mtime +11 | xargs rm -f

    # image import directories
    cd ${EXCELSA_IMPORT_DIR}/in_ddp &&  find . -name '*' -mtime +11 | xargs rm -f

    # PictureDesk import directories
#    cd ${EXCELSA_IMPORT_DIR}/pd_buntes &&  find . -name '*' -mtime +11 | xargs rm -f

    #directories for successfully imported files
    cd ${EXCELSA_IMPORT_DIR}/_done &&  find . -name '???*' -mtime +1 -print0 | xargs -0 rm -f

    #directory for files with import errors
    cd ${EXCELSA_IMPORT_DIR}/_error &&  find . -name '???*' -mtime +61 -print0 | xargs -0 rm -f
fi
