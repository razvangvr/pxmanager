#!/bin/sh

. /appl/mars/bin/excelsa_node_conf
export JAVA_HOME=/opt/java

/appl/mars/jboss-prod/bin/shutdown.sh -u admin -p newsfact -s jnp://${EXCELSA_CLUSTER_NODE_IP}:1099
