#!/bin/sh

DATE=$(date +"%Y%m%d%R") 

if [ `whoami` != "ddpsrv" ];
then
  su - ddpsrv -c "/appl/ddp/bin/startjboss-development.sh"
  exit
fi

# fuer native-connector
# export LD_LIBRARY_PATH=/opt/libapreq-1.2/lib
# export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/opt/jboss-native-2.0.6-linux2-x86-ssl/bin/META-INF/lib/linux2/x86

export JAVA_HOME=/opt/jdk1.6.0_13

cp /appl/ddp/logs/server-development.log /appl/ddp/logs/server-development.log_$DATE 
cp /appl/ddp/logs/excelsa-error-development.log /appl/ddp/logs/excelsa-error-development.log_$DATE 

rm -rf /appl/ddp/jboss-development/server/all/work
rm -rf /appl/ddp/jboss-development/server/all/tmp
rm -rf /appl/ddp/jboss-development/server/all/data

nohup /appl/ddp/jboss-development/bin/run.sh \
-b ddpentw.ise.apa.at \
-Djboss.bind.port=18080 \
--configuration=all \
-Dfile.encoding=UTF-8 \
> /appl/ddp/bin/nohup-development.out 2>&1 &

