#!/bin/sh

export JAVA_HOME=/opt/jdk1.6.0_13

/appl/ddp/jboss-development/bin/shutdown.sh -s jnp://ddpentw.ise.apa.at:11099
