#!/bin/sh

DATE=$(date +"%Y%m%d%R") 

. /appl/mars/bin/excelsa_node_conf

if [ `whoami` != "mars" ];
then
  su - mars -c "${BASE_DIR}/bin/startjboss-prod.sh"
  exit
fi

# fuer native-connector
# export LD_LIBRARY_PATH=/opt/libapreq-1.2/lib
# export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/opt/jboss-native-2.0.6-linux2-x86-ssl/bin/META-INF/lib/linux2/x86

export JAVA_HOME=/opt/java

cp ${BASE_DIR}/logs/server-prod.log ${BASE_DIR}/logs/server-prod.log_$DATE 
cp ${BASE_DIR}/logs/excelsa-error-prod.log ${BASE_DIR}/logs/excelsa-error-prod.log_$DATE 

rm -rf ${BASE_DIR}/jboss-prod/server/all/work
rm -rf ${BASE_DIR}/jboss-prod/server/all/tmp
rm -rf ${BASE_DIR}/jboss-prod/server/all/data

nohup ${BASE_DIR}/jboss-prod/bin/run.sh \
-b ${EXCELSA_CLUSTER_NODE_IP} \
-g ${EXCELSA_CLUSTER_PARTITION_NAME} \
-Djboss.bind.port=8080 \
-c all \
-Dfile.encoding=UTF-8 \
-Djavax.net.ssl.keyStore=$JBOSS_HOME/server/all/conf/server.keystore \
-Djavax.net.ssl.keyStorePassword=opensource \
-Djava.protocol.handler.pkgs=javax.net.ssl \
> ${BASE_DIR}/bin/nohup-prod.out 2>&1 &
